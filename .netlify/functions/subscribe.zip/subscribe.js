var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var subscribe_exports = {};
__export(subscribe_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(subscribe_exports);
const https = require("https");
async function handler(event, context) {
  try {
    if (event.httpMethod !== "POST") {
      return {
        statusCode: 405,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "Method Not Allowed" })
      };
    }
    const { name, email, type } = JSON.parse(event.body || "{}");
    if (!email) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E23\u0E2D\u0E01\u0E2D\u0E35\u0E40\u0E21\u0E25" })
      };
    }
    const RESEND_API_KEY = process.env.RESEND_API_KEY;
    const FROM_EMAIL = process.env.FROM_EMAIL || "BIZ IDEA <noreply@yourdomain.com>";
    const SITE_URL = process.env.SITE_URL || "https://idea2cash.netlify.app";
    const EBOOK_URL = process.env.EBOOK_URL || "https://drive.google.com/file/d/1_JS1FIR87aHSgtOHROH384eYzDgeBbYh/view?usp=sharing";
    const WORKSHOP_URL = process.env.WORKSHOP_URL || `${SITE_URL}/workshop.html#pricing`;
    const OWNER_EMAIL = process.env.OWNER_EMAIL || "";
    if (!RESEND_API_KEY) {
      console.error("RESEND_API_KEY not found");
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "Server configuration error" })
      };
    }
    const isEbook = type === "ebook";
    let subject, htmlContent, successMessage;
    if (isEbook) {
      subject = "eBook \u0E1F\u0E23\u0E35: Idea\u2192Cash Sprint - \u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22!";
      htmlContent = `
        <p>\u0E2A\u0E27\u0E31\u0E2A\u0E14\u0E35\u0E04\u0E38\u0E13 ${name || "\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E19 BIZ IDEA"},</p>
        <p>\u0E02\u0E2D\u0E1A\u0E04\u0E38\u0E13\u0E17\u0E35\u0E48\u0E2A\u0E19\u0E43\u0E08 eBook "Idea\u2192Cash Sprint" \u0E04\u0E23\u0E31\u0E1A</p>
        <p><strong>\u{1F389} \u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14 eBook \u0E1F\u0E23\u0E35\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22\u0E17\u0E35\u0E48\u0E19\u0E35\u0E48:</strong></p>
        <p><a href="${EBOOK_URL}" style="background: linear-gradient(135deg,#FF6B35 0%,#F7931E 100%); color: white; padding: 12px 24px; border-radius: 25px; text-decoration: none; display: inline-block; font-weight: 600;">\u{1F4DA} \u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14 eBook \u0E1F\u0E23\u0E35</a></p>
        <p><strong>\u{1F381} \u0E42\u0E1A\u0E19\u0E31\u0E2A: Starter Kit \u0E1F\u0E23\u0E35!</strong></p>
        <p><a href="https://docs.google.com/spreadsheets/d/1vg7N9SZSYdP8ZRai1XeIXC4EcGdt-9zH/edit?usp=sharing&ouid=118248382152291538899&rtpof=true&sd=true" style="background: linear-gradient(135deg,#28a745 0%,#20c997 100%); color: white; padding: 12px 24px; border-radius: 25px; text-decoration: none; display: inline-block; font-weight: 600;">\u{1F4CA} \u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14 Starter Kit</a></p>
        <p>\u{1F4D6} <strong>\u0E2A\u0E34\u0E48\u0E07\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E08\u0E30\u0E44\u0E14\u0E49\u0E40\u0E23\u0E35\u0E22\u0E19\u0E43\u0E19 ebook \u0E19\u0E35\u0E49:</strong></p>
        <ul>
          <li>\u{1F680} Quick Start 24 \u0E0A\u0E21. - \u0E40\u0E23\u0E34\u0E48\u0E21\u0E08\u0E32\u0E01\u0E28\u0E39\u0E19\u0E22\u0E4C\u0E43\u0E2B\u0E49\u0E44\u0E14\u0E49\u0E40\u0E07\u0E34\u0E19\u0E40\u0E23\u0E47\u0E27\u0E17\u0E35\u0E48\u0E2A\u0E38\u0E14</li>
          <li>\u{1F4CA} RICE Framework + MVP Library - \u0E27\u0E34\u0E18\u0E35\u0E43\u0E2B\u0E49\u0E04\u0E30\u0E41\u0E19\u0E19\u0E44\u0E2D\u0E40\u0E14\u0E35\u0E22</li>
          <li>\u{1F4B0} Offer 3 \u0E41\u0E1E\u0E47\u0E01 - \u0E2A\u0E39\u0E15\u0E23\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E02\u0E32\u0E22 + \u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E23\u0E32\u0E04\u0E32</li>
          <li>\u{1F4C8} Tracking \u0E07\u0E48\u0E32\u0E22 - \u0E27\u0E34\u0E18\u0E35\u0E15\u0E34\u0E14\u0E15\u0E32\u0E21 Conversion, CAC</li>
          <li>\u{1F3AF} \u0E40\u0E17\u0E21\u0E40\u0E1E\u0E25\u0E15\u0E04\u0E23\u0E1A\u0E0A\u0E38\u0E14 - \u0E41\u0E1A\u0E1A\u0E1F\u0E2D\u0E23\u0E4C\u0E21\u0E41\u0E25\u0E30\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D\u0E17\u0E35\u0E48\u0E08\u0E33\u0E40\u0E1B\u0E47\u0E19</li>
          <li>\u{1F4DA} \u0E40\u0E04\u0E2A\u0E2A\u0E15\u0E31\u0E14\u0E35 10 \u0E40\u0E04\u0E2A - \u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E08\u0E23\u0E34\u0E07\u0E08\u0E32\u0E01\u0E1C\u0E39\u0E49\u0E1B\u0E23\u0E30\u0E01\u0E2D\u0E1A\u0E01\u0E32\u0E23</li>
        </ul>
        <p>\u0E2B\u0E32\u0E01\u0E2A\u0E19\u0E43\u0E08\u0E40\u0E23\u0E35\u0E22\u0E19\u0E41\u0E1A\u0E1A\u0E2A\u0E14\u0E41\u0E25\u0E30\u0E44\u0E14\u0E49\u0E04\u0E33\u0E41\u0E19\u0E30\u0E19\u0E33\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21 \u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E14\u0E39 Workshop \u0E44\u0E14\u0E49\u0E17\u0E35\u0E48: <a href="${WORKSHOP_URL}">Workshop Idea\u2192Cash Sprint</a></p>
        <p>\u0E02\u0E2D\u0E43\u0E2B\u0E49\u0E1B\u0E23\u0E30\u0E2A\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08\u0E01\u0E31\u0E1A\u0E01\u0E32\u0E23\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E44\u0E2D\u0E40\u0E14\u0E35\u0E22\u0E40\u0E1B\u0E47\u0E19\u0E40\u0E07\u0E34\u0E19\u0E04\u0E23\u0E31\u0E1A!</p>
        <p>\u0E23\u0E13\u0E22\u0E28<br>BIZ IDEA<br><a href="${SITE_URL}">${SITE_URL}</a></p>
      `;
      successMessage = "\u0E2A\u0E48\u0E07\u0E25\u0E34\u0E07\u0E01\u0E4C eBook \u0E44\u0E1B\u0E17\u0E35\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25\u0E41\u0E25\u0E49\u0E27";
    } else {
      subject = "\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E17\u0E35\u0E48\u0E19\u0E31\u0E48\u0E07 Workshop \u0E15.\u0E04. 2025";
      htmlContent = `
        <p>\u0E2A\u0E27\u0E31\u0E2A\u0E14\u0E35\u0E04\u0E38\u0E13 ${name || "\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E19 BIZ IDEA"},</p>
        <p>\u0E02\u0E2D\u0E1A\u0E04\u0E38\u0E13\u0E17\u0E35\u0E48\u0E2A\u0E19\u0E43\u0E08 Workshop "Idea\u2192Cash Sprint" \u0E40\u0E14\u0E37\u0E2D\u0E19\u0E15\u0E38\u0E25\u0E32\u0E04\u0E21 2025 \u0E19\u0E30\u0E04\u0E23\u0E31\u0E1A</p>
        <p><strong>\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E01\u0E32\u0E23 Workshop \u0E2A\u0E14:</strong> \u0E40\u0E25\u0E37\u0E2D\u0E01\u0E40\u0E23\u0E35\u0E22\u0E19\u0E44\u0E14\u0E49 1 \u0E27\u0E31\u0E19<br>
        \u0E40\u0E2A\u0E32\u0E23\u0E4C 11, \u0E2D\u0E32\u0E17\u0E34\u0E15\u0E22\u0E4C 12, \u0E40\u0E2A\u0E32\u0E23\u0E4C 18, \u0E2D\u0E32\u0E17\u0E34\u0E15\u0E22\u0E4C 19, \u0E40\u0E2A\u0E32\u0E23\u0E4C 25, \u0E2D\u0E32\u0E17\u0E34\u0E15\u0E22\u0E4C 26 \u0E15.\u0E04. 2025<br>
        \u0E40\u0E27\u0E25\u0E32 10:00\u201317:00 \u0E19. (GMT+7) | \u0E1C\u0E48\u0E32\u0E19 Zoom</p>
        <p>\u0E19\u0E35\u0E48\u0E04\u0E37\u0E2D\u0E02\u0E31\u0E49\u0E19\u0E15\u0E2D\u0E19\u0E15\u0E48\u0E2D\u0E44\u0E1B:</p>
        <ol>
          <li><strong>\u0E0A\u0E33\u0E23\u0E30\u0E40\u0E07\u0E34\u0E19:</strong> \u0E42\u0E2D\u0E19\u0E40\u0E07\u0E34\u0E19\u0E21\u0E32\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E0D\u0E0A\u0E35 <strong>BBL 1384416804 (\u0E23\u0E13\u0E22\u0E28 \u0E15\u0E31\u0E19\u0E15\u0E34\u0E16\u0E32\u0E27\u0E23\u0E23\u0E31\u0E0A)</strong> \u0E15\u0E32\u0E21\u0E41\u0E1E\u0E47\u0E01\u0E40\u0E01\u0E08\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E40\u0E25\u0E37\u0E2D\u0E01</li>
          <li><strong>\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E32\u0E23\u0E0A\u0E33\u0E23\u0E30\u0E40\u0E07\u0E34\u0E19:</strong> \u0E41\u0E19\u0E1A\u0E2A\u0E25\u0E34\u0E1B\u0E41\u0E25\u0E30\u0E41\u0E08\u0E49\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48 <a href="https://docs.google.com/forms/d/e/1FAIpQLSdkYo6AaBnYVdrZb_WxfPDkX0UcX2NdJPW1LpF6Hd2qaeqd5A/viewform?usp=header">Google Form \u0E19\u0E35\u0E49</a></li>
        </ol>
        <p>\u0E2B\u0E25\u0E31\u0E07\u0E08\u0E32\u0E01\u0E17\u0E35\u0E21\u0E07\u0E32\u0E19\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E41\u0E25\u0E49\u0E27 \u0E08\u0E30\u0E2A\u0E48\u0E07\u0E25\u0E34\u0E07\u0E01\u0E4C Zoom \u0E41\u0E25\u0E30\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14\u0E01\u0E32\u0E23\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E15\u0E31\u0E27\u0E43\u0E2B\u0E49\u0E17\u0E32\u0E07\u0E2D\u0E35\u0E40\u0E21\u0E25\u0E20\u0E32\u0E22\u0E43\u0E19 24 \u0E0A\u0E31\u0E48\u0E27\u0E42\u0E21\u0E07\u0E04\u0E23\u0E31\u0E1A</p>
        <p>\u0E40\u0E08\u0E2D\u0E01\u0E31\u0E19\u0E43\u0E19\u0E04\u0E25\u0E32\u0E2A\u0E04\u0E23\u0E31\u0E1A!</p>
        <p>\u0E23\u0E13\u0E22\u0E28<br>BIZ IDEA<br><a href="${SITE_URL}">${SITE_URL}</a></p>
      `;
      successMessage = "\u0E2A\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E01\u0E32\u0E23\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E17\u0E35\u0E48\u0E19\u0E31\u0E48\u0E07\u0E44\u0E1B\u0E17\u0E35\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25\u0E41\u0E25\u0E49\u0E27";
    }
    const fetch = globalThis.fetch || (await import("node-fetch")).default;
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: [email],
        subject,
        html: htmlContent
      })
    });
    if (!res.ok) {
      const errorText = await res.text();
      console.error("Resend API error:", res.status, errorText);
      return {
        statusCode: 502,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "\u0E2A\u0E48\u0E07\u0E2D\u0E35\u0E40\u0E21\u0E25\u0E44\u0E21\u0E48\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08" })
      };
    }
    if (OWNER_EMAIL) {
      try {
        await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${RESEND_API_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            from: FROM_EMAIL,
            to: [OWNER_EMAIL],
            subject: isEbook ? "New eBook lead" : "New Workshop lead",
            text: `Type: ${isEbook ? "eBook" : "Workshop"}
Name: ${name || ""}
Email: ${email}`
          })
        });
      } catch (e) {
        console.error("Owner notification error:", e);
      }
    }
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: successMessage })
    };
  } catch (err) {
    console.error("Function error:", err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14" })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
